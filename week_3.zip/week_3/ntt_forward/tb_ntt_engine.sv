`timescale 1ns/1ps

module tb_ntt_engine;
    logic clk_i = 1'b0;
    logic rst_ni = 1'b0;
    logic start_i = 1'b0;
    logic mode_i = 1'b0;
    logic wr_en_i = 1'b0;
    logic [7:0] wr_addr_i = 8'd0;
    logic [23:0] wr_data_i = 24'd0;
    logic [7:0] rd_addr_i = 8'd0;
    logic [23:0] rd_data_o;
    logic busy_o, done_o, error_o;
    logic [23:0] input_vector [0:255];
    logic [23:0] expected_vector [0:255];
    integer tests = 0;

    always #5 clk_i = ~clk_i;

    ntt_engine dut (
        .clk_i(clk_i), .rst_ni(rst_ni), .start_i(start_i), .mode_i(mode_i),
        .wr_en_i(wr_en_i), .wr_addr_i(wr_addr_i), .wr_data_i(wr_data_i),
        .rd_addr_i(rd_addr_i), .rd_data_o(rd_data_o), .busy_o(busy_o),
        .done_o(done_o), .error_o(error_o)
    );

    task automatic run_case(input logic mode, input integer case_number);
        string prefix;
        integer cycles;
        begin
            prefix = mode ? "dilithium" : "kyber";
            $readmemh($sformatf("%s_input_%0d.hex", prefix, case_number), input_vector);
            $readmemh($sformatf("%s_expected_%0d.hex", prefix, case_number), expected_vector);

            for (integer i = 0; i < 256; i = i + 1) begin
                @(negedge clk_i);
                wr_en_i   = 1'b1;
                wr_addr_i = i[7:0];
                wr_data_i = input_vector[i];
            end

            @(negedge clk_i);
            wr_en_i = 1'b0;
            mode_i  = mode;
            start_i = 1'b1;
            @(posedge clk_i);
            #1;
            if (!busy_o || done_o || error_o)
                $fatal(1, "Start failed for %s case %0d", prefix, case_number);

            @(negedge clk_i);
            start_i   = 1'b0;
            mode_i    = ~mode; // The engine must use its latched mode.
            wr_en_i   = 1'b1;  // A host write while busy must be ignored.
            wr_addr_i = 8'd0;
            wr_data_i = 24'hffffff;
            @(negedge clk_i);
            wr_en_i = 1'b0;

            cycles = 0;
            while (!done_o && cycles < 1600) begin
                @(posedge clk_i);
                #1;
                cycles = cycles + 1;
            end
            if (!done_o || busy_o || error_o)
                $fatal(1, "Timeout/status error: %s case %0d cycles %0d", prefix, case_number, cycles);

            for (integer i = 0; i < 256; i = i + 1) begin
                rd_addr_i = i[7:0];
                #1;
                if (rd_data_o !== expected_vector[i])
                    $fatal(1, "%s case %0d index %0d: expected %0d, got %0d",
                           prefix, case_number, i, expected_vector[i], rd_data_o);
            end
            tests = tests + 1;
            $display("PASS %s case %0d", prefix, case_number);
        end
    endtask

    initial begin
        repeat (3) @(negedge clk_i);
        rst_ni = 1'b1;
        for (integer mode = 0; mode < 2; mode = mode + 1)
            for (integer case_number = 0; case_number < 8; case_number = case_number + 1)
                run_case(mode[0], case_number);
        $display("PASS: %0d complete NTT transforms, 4096 output comparisons", tests);
        $finish;
    end
endmodule
