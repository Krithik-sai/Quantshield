// Configurable forward-NTT Cooley-Tukey butterfly.
//
// modulus_sel_i = 0: ML-KEM / Kyber,      q = 3,329
// modulus_sel_i = 1: ML-DSA / Dilithium,  q = 8,380,417
//
// Valid-input contract:
//   0 <= a_i, b_i, w_i < q
//
// Computation:
//   t   = (b_i * w_i) mod q
//   a_o = (a_i + t) mod q
//   b_o = (a_i - t) mod q
//
// Barrett reciprocal:
//   MU = floor(2^48 / q)

module butterfly_path (
    input  logic        modulus_sel_i,
    input  logic [23:0] a_i,
    input  logic [23:0] b_i,
    input  logic [23:0] w_i,
    output logic [23:0] a_o,
    output logic [23:0] b_o
);

    localparam logic [23:0] Q_KYBER       = 24'd3329;
    localparam logic [23:0] Q_DILITHIUM   = 24'd8380417;

    // floor(2^48 / 3329)    = 84,552,411,147
    // floor(2^48 / 8380417) = 33,587,228
    localparam logic [47:0] MU_KYBER      = 48'd84552411147;
    localparam logic [47:0] MU_DILITHIUM  = 48'd33587228;

    logic [23:0] q;
    logic [47:0] mu;

    logic [47:0] b_ext;
    logic [47:0] w_ext;
    logic [47:0] product;

    logic [95:0] product_ext;
    logic [95:0] mu_ext;
    logic [95:0] scaled_product;
    logic [47:0] quotient_estimate;

    logic [71:0] quotient_ext;
    logic [71:0] q_ext;
    logic [71:0] quotient_times_q;
    logic [71:0] product_72;
    logic [71:0] remainder_full;

    logic [23:0] t_mod;
    logic [24:0] sum_full;

    always_comb begin
        if (modulus_sel_i == 1'b0) begin
            q  = Q_KYBER;
            mu = MU_KYBER;
        end else begin
            q  = Q_DILITHIUM;
            mu = MU_DILITHIUM;
        end

        // 24-bit x 24-bit coefficient/twiddle multiplication.
        b_ext   = {24'd0, b_i};
        w_ext   = {24'd0, w_i};
        product = b_ext * w_ext;

        // Barrett quotient estimate:
        //   quotient_estimate = floor(product * MU / 2^48)
        product_ext       = {48'd0, product};
        mu_ext            = {48'd0, mu};
        scaled_product    = product_ext * mu_ext;
        quotient_estimate = scaled_product[95:48];

        // Preliminary remainder. Because product < q^2 and q < 2^24,
        // this reciprocal choice guarantees 0 <= remainder_full < 2q.
        quotient_ext      = {24'd0, quotient_estimate};
        q_ext             = {48'd0, q};
        quotient_times_q  = quotient_ext * q_ext;
        product_72        = {24'd0, product};
        remainder_full    = product_72 - quotient_times_q;

        // One conditional subtraction gives the canonical residue [0, q-1].
        if (remainder_full >= q_ext)
            t_mod = remainder_full[23:0] - q;
        else
            t_mod = remainder_full[23:0];

        // Modular addition: a_o = (a_i + t_mod) mod q.
        sum_full = {1'b0, a_i} + {1'b0, t_mod};
        if (sum_full >= {1'b0, q})
            a_o = sum_full[23:0] - q;
        else
            a_o = sum_full[23:0];

        // Modular subtraction: b_o = (a_i - t_mod) mod q.
        if (a_i >= t_mod)
            b_o = a_i - t_mod;
        else
            b_o = a_i + q - t_mod;
    end

endmodule
