from pathlib import Path
from random import Random


OUT = Path(__file__).resolve().parent
MODES = (("kyber", 3329, 17, 7, 128), ("dilithium", 8380417, 1753, 8, 256))


def bit_reverse(x, width):
    y = 0
    for _ in range(width):
        y = (y << 1) | (x & 1)
        x >>= 1
    return y


def evaluate_direct(a, q, root, bits, length):
    """Evaluate at odd roots directly, independently of the butterfly schedule."""
    result = []
    for index in range(length):
        x = pow(root, 2 * bit_reverse(index, bits) + 1, q)
        power, total = 1, 0
        for coefficient in (a if length == 256 else a[::2]):
            total = (total + coefficient * power) % q
            power = power * x % q
        result.append(total)
        if length == 128:
            power, total = 1, 0
            for coefficient in a[1::2]:
                total = (total + coefficient * power) % q
                power = power * x % q
            result.append(total)
    return result


def write_hex(name, values):
    (OUT / name).write_text("".join(f"{v:06X}\n" for v in values), encoding="ascii")


def main():
    for mode, q, root, bits, length in MODES:
        vectors = [
            [0] * 256,
            [1] + [0] * 255,
            [0] * 255 + [1],
            [i % q for i in range(256)],
            [q - 1 if i & 1 else 0 for i in range(256)],
        ]
        for seed in (17, 101, 2026):
            rng = Random(seed)
            vectors.append([rng.randrange(q) for _ in range(256)])

        for case, values in enumerate(vectors):
            expected = evaluate_direct(values, q, root, bits, length)
            assert len(expected) == 256
            assert all(0 <= v < q for v in expected)
            write_hex(f"{mode}_input_{case}.hex", values)
            write_hex(f"{mode}_expected_{case}.hex", expected)
        print(f"{mode}: generated {len(vectors)} complete input/output pairs")


if __name__ == "__main__":
    main()
