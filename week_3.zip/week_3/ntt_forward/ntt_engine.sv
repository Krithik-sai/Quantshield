module ntt_engine (
    input  logic        clk_i,
    input  logic        rst_ni,
    input  logic        start_i,
    input  logic        mode_i,       // 0: ML-KEM, 1: ML-DSA
    input  logic        wr_en_i,
    input  logic [7:0]  wr_addr_i,
    input  logic [23:0] wr_data_i,
    input  logic [7:0]  rd_addr_i,
    output logic [23:0] rd_data_o,
    output logic        busy_o,
    output logic        done_o,
    output logic        error_o
);
    // One coefficient per word. Load all 256 entries before start_i.
    // Host writes are ignored during a transform; reads are asynchronous.
    logic [23:0] coeff_mem [0:255];

    typedef enum logic [1:0] {IDLE, TWIDDLE_REQUEST, BUTTERFLY} state_t;
    state_t state_q;

    logic       mode_q;
    logic [7:0] half_q;
    logic [7:0] group_q;
    logic [7:0] offset_q;
    logic [7:0] twiddle_addr_q;
    logic [8:0] first_addr;
    logic [8:0] second_addr;
    logic [8:0] next_group;
    logic [23:0] twiddle;
    logic        twiddle_valid;
    logic [23:0] result_first;
    logic [23:0] result_second;

    assign first_addr  = {1'b0, group_q} + {1'b0, offset_q};
    assign second_addr = first_addr + {1'b0, half_q};
    assign next_group  = {1'b0, group_q} + ({1'b0, half_q} << 1);
    assign rd_data_o   = coeff_mem[rd_addr_i];
    assign busy_o      = (state_q != IDLE);

    twiddle_rom rom (
        .clk_i(clk_i),
        .rst_ni(rst_ni),
        .mode_i(mode_q),
        .addr_i(twiddle_addr_q),
        .twiddle_o(twiddle),
        .valid_o(twiddle_valid)
    );

    butterfly_path butterfly (
        .modulus_sel_i(mode_q),
        .a_i(coeff_mem[first_addr[7:0]]),
        .b_i(coeff_mem[second_addr[7:0]]),
        .w_i(twiddle),
        .a_o(result_first),
        .b_o(result_second)
    );

    always_ff @(posedge clk_i) begin
        if (!rst_ni) begin
            state_q        <= IDLE;
            mode_q         <= 1'b0;
            half_q         <= 8'd128;
            group_q        <= 8'd0;
            offset_q       <= 8'd0;
            twiddle_addr_q <= 8'd0;
            done_o         <= 1'b0;
            error_o        <= 1'b0;
        end else begin
            case (state_q)
                IDLE: begin
                    if (start_i) begin
                        mode_q         <= mode_i;
                        half_q         <= 8'd128;
                        group_q        <= 8'd0;
                        offset_q       <= 8'd0;
                        twiddle_addr_q <= 8'd0;
                        done_o         <= 1'b0;
                        error_o        <= 1'b0;
                        state_q        <= TWIDDLE_REQUEST;
                    end else if (wr_en_i) begin
                        coeff_mem[wr_addr_i] <= wr_data_i;
                    end
                end

                // The ROM registers its output on this clock edge.
                TWIDDLE_REQUEST: state_q <= BUTTERFLY;

                BUTTERFLY: begin
                    if (!twiddle_valid) begin
                        error_o <= 1'b1;
                        done_o  <= 1'b1;
                        state_q <= IDLE;
                    end else begin
                        coeff_mem[first_addr[7:0]]  <= result_first;
                        coeff_mem[second_addr[7:0]] <= result_second;

                        if ({1'b0, offset_q} + 9'd1 < {1'b0, half_q}) begin
                            offset_q <= offset_q + 8'd1;
                        end else if (next_group < 9'd256) begin
                            group_q        <= next_group[7:0];
                            offset_q       <= 8'd0;
                            twiddle_addr_q <= twiddle_addr_q + 8'd1;
                            state_q        <= TWIDDLE_REQUEST;
                        end else if (half_q == (mode_q ? 8'd1 : 8'd2)) begin
                            done_o  <= 1'b1;
                            state_q <= IDLE;
                        end else begin
                            half_q         <= half_q >> 1;
                            group_q        <= 8'd0;
                            offset_q       <= 8'd0;
                            twiddle_addr_q <= twiddle_addr_q + 8'd1;
                            state_q        <= TWIDDLE_REQUEST;
                        end
                    end
                end

                default: state_q <= IDLE;
            endcase
        end
    end
endmodule
