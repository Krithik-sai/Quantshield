// NTT controller: forward NTT for ML-KEM (sel=0) or ML-DSA (sel=1).
//
// The twiddle factors are NOT generated here: the controller drives tw_addr and
// consumes tw_data from an external twiddle source (e.g. ntt_twiddle_rom, which is
// loaded from the Python-generated .mem files).
//
//   tw_addr = index of the current block's twiddle = position in the *_twiddles_*.mem
//             file (0 .. 126 for Kyber, 0 .. 254 for Dilithium)
//   tw_data must be valid ONE clock after tw_addr (synchronous ROM/BRAM).
//
// Schedule (identical to the Python generators, FIPS 203 Alg.9 / FIPS 204 Alg.41):
//   Kyber    : len 128..2  (7 layers, 896 butterflies)
//   Dilithium: len 128..1  (8 layers, 1024 butterflies)
//   Per butterfly:  t = tw*x[j+len];  x[j+len] = x[j]-t;  x[j] = x[j]+t   (mod q)
//
// Flow: load coefficients (wr_*) while idle, set sel, pulse start, wait for done,
//       read results (rd_*). sel is latched on start.  3 clocks per butterfly.
module ntt_ctrl
  import Butterfly::*;
#(
  parameter int W = 24
) (
  input  logic         clk,
  input  logic         rst_n,

  input  logic         sel,        // 0 = Kyber q, 1 = Dilithium q
  input  logic         start,
  output logic         busy,
  output logic         done,       // 1-cycle pulse

  input  logic         wr_en,      // coefficient load (only while !busy)
  input  logic [7:0]   wr_addr,
  input  logic [W-1:0] wr_data,

  input  logic [7:0]   rd_addr,    // result read (async)
  output logic [W-1:0] rd_data,

  output logic [7:0]   tw_addr,    // to twiddle ROM
  input  logic [W-1:0] tw_data     // from twiddle ROM, 1 cycle later
);

  logic [W-1:0] mem [0:255];

  typedef enum logic [1:0] {S_IDLE, S_ADDR, S_READ, S_WRITE} state_t;
  state_t state;

  logic        sel_r;
  logic [8:0]  len, blk_start, j;
  logic [7:0]  m;                       // twiddle index, ++ per block
  logic [W-1:0] a_r, b_r, z_r;
  logic [W-1:0] bf_sum, bf_diff;

  wire [8:0] len_min    = sel_r ? 9'd1 : 9'd2;
  wire       blk_last   = (j == blk_start + len - 9'd1);
  wire [9:0] nxt_start  = {1'b0, blk_start} + {len, 1'b0};
  wire       layer_last = (nxt_start >= 10'd256);

  ntt_butterfly #(.W(W)) u_bf (
    .sel(sel_r), .a(a_r), .b(b_r), .zeta(z_r), .sum(bf_sum), .diff(bf_diff)
  );

  assign tw_addr = m;
  assign busy    = (state != S_IDLE);
  assign rd_data = mem[rd_addr];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= S_IDLE; done <= 1'b0; sel_r <= 1'b0;
      len <= 9'd128; blk_start <= '0; j <= '0; m <= '0;
      a_r <= '0; b_r <= '0; z_r <= '0;
    end else begin
      done <= 1'b0;
      case (state)
        S_IDLE: begin
          if (wr_en) mem[wr_addr] <= wr_data;
          if (start) begin
            sel_r <= sel; len <= 9'd128; blk_start <= '0; j <= '0; m <= '0;
            state <= S_ADDR;
          end
        end

        S_ADDR:  state <= S_READ;            // tw_addr presented, ROM latches it

        S_READ: begin                        // tw_data now valid
          a_r <= mem[j[7:0]];
          b_r <= mem[j[7:0] + len[7:0]];
          z_r <= tw_data;
          state <= S_WRITE;
        end

        S_WRITE: begin
          mem[j[7:0]]            <= bf_sum;
          mem[j[7:0] + len[7:0]] <= bf_diff;

          if (!blk_last) begin
            j     <= j + 9'd1;
            state <= S_READ;                 // same block -> same twiddle, no ROM wait
          end else begin
            m <= m + 8'd1;                   // next block -> next twiddle
            if (!layer_last) begin
              blk_start <= nxt_start[8:0]; j <= nxt_start[8:0]; state <= S_ADDR;
            end else if (len != len_min) begin
              len <= len >> 1; blk_start <= '0; j <= '0; state <= S_ADDR;
            end else begin
              state <= S_IDLE; done <= 1'b1;
            end
          end
        end
      endcase
    end
  end
endmodule
