// Radix-2 Cooley-Tukey butterfly, runtime-selectable modulus.
//   sel = 0 : ML-KEM / Kyber      (q = Q_KYBER,     MU_KYBER)
//   sel = 1 : ML-DSA / Dilithium  (q = Q_DILITHIUM, MU_DILITHIUM)
//   t = (zeta*b) mod q (Barrett, k=48);  sum = (a+t) mod q;  diff = (a-t) mod q
// a, b, zeta must be < q.
module ntt_butterfly
  import Butterfly::*;
#(
  parameter int W = 24
) (
  input  logic         sel,
  input  logic [W-1:0] a,
  input  logic [W-1:0] b,
  input  logic [W-1:0] zeta,
  output logic [W-1:0] sum,
  output logic [W-1:0] diff
);
 
  logic [W-1:0]        Q;
  logic [MU_WIDTH-1:0] MU;
 
  logic [X_WIDTH-1:0]          x;
  logic [X_WIDTH+MU_WIDTH-1:0] xmu;
  logic [X_WIDTH-1:0]          qest, r_full;
  logic [W:0]                  r;
  logic [W-1:0]                t;
  logic [W:0]                  s_raw, d_raw;
 
  always_comb begin
    Q  = sel ? W'(Q_DILITHIUM)  : W'(Q_KYBER);
    MU = sel ? MU_DILITHIUM     : MU_KYBER;
 
    // Barrett: qest in {floor(x/q)-1, floor(x/q)}  ->  r in [0,2q)
    x      = X_WIDTH'(zeta) * X_WIDTH'(b);
    xmu    = x * MU;
    qest   = xmu[K +: X_WIDTH];
    r_full = x - qest * X_WIDTH'(Q);
    r      = r_full[W:0];
    t      = (r >= {1'b0, Q}) ? W'(r - {1'b0, Q}) : r[W-1:0];
 
    s_raw = {1'b0, a} + {1'b0, t};
    sum   = (s_raw >= {1'b0, Q}) ? W'(s_raw - {1'b0, Q}) : s_raw[W-1:0];
 
    d_raw = {1'b0, a} - {1'b0, t};
    diff  = d_raw[W] ? W'(d_raw + {1'b0, Q}) : d_raw[W-1:0];
  end
endmodule
