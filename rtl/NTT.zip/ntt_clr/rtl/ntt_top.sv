// ntt_ctrl + twiddle ROM. sel: 0 = Kyber (q=3329), 1 = Dilithium (q=8380417).
module ntt_top #(
  parameter int W = 24,
  parameter string KYBER_MEM     = "twiddle/kyber_twiddles_hex_correct.mem",
  parameter string DILITHIUM_MEM = "twiddle/dilithium_twiddles_hex_correct.mem"
) (
  input  logic         clk, rst_n,
  input  logic         sel, start,
  output logic         busy, done,
  input  logic         wr_en,
  input  logic [7:0]   wr_addr,
  input  logic [W-1:0] wr_data,
  input  logic [7:0]   rd_addr,
  output logic [W-1:0] rd_data
);
  logic [7:0]   tw_addr;
  logic [W-1:0] tw_data;

  ntt_ctrl #(.W(W)) u_ctrl (.*);
  ntt_twiddle_rom #(.W(W), .KYBER_MEM(KYBER_MEM), .DILITHIUM_MEM(DILITHIUM_MEM))
    u_rom (.clk, .sel, .addr(tw_addr), .data(tw_data));
endmodule
