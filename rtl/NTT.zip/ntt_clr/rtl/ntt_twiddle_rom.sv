// Twiddle ROM loaded from the Python-generated .mem files.
// sel = 0 -> Kyber table (127 entries), sel = 1 -> Dilithium table (255 entries).
// Synchronous read (1-cycle latency) so it maps onto block RAM.
module ntt_twiddle_rom #(
  parameter int W = 24,
  parameter string KYBER_MEM     = "twiddle/kyber_twiddles_hex_correct.mem",
  parameter string DILITHIUM_MEM = "twiddle/dilithium_twiddles_hex_correct.mem"
) (
  input  logic         clk,
  input  logic         sel,
  input  logic [7:0]   addr,
  output logic [W-1:0] data
);
  logic [W-1:0] rom_k [0:126];
  logic [W-1:0] rom_d [0:254];

  initial begin
    $readmemh(KYBER_MEM,     rom_k);
    $readmemh(DILITHIUM_MEM, rom_d);
  end

  always_ff @(posedge clk)
    data <= sel ? rom_d[addr] : rom_k[addr[6:0]];
endmodule
