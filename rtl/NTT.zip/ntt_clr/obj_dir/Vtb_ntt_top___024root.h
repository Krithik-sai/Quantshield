// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtb_ntt_top.h for the primary calling header

#ifndef VERILATED_VTB_NTT_TOP___024ROOT_H_
#define VERILATED_VTB_NTT_TOP___024ROOT_H_  // guard

#include "verilated.h"
#include "verilated_timing.h"


class Vtb_ntt_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtb_ntt_top___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ tb_ntt_top__DOT__clk;
    CData/*0:0*/ tb_ntt_top__DOT__rst_n;
    CData/*0:0*/ tb_ntt_top__DOT__sel;
    CData/*0:0*/ tb_ntt_top__DOT__start;
    CData/*0:0*/ tb_ntt_top__DOT__done;
    CData/*0:0*/ tb_ntt_top__DOT__wr_en;
    CData/*7:0*/ tb_ntt_top__DOT__wr_addr;
    CData/*7:0*/ tb_ntt_top__DOT__rd_addr;
    CData/*1:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state;
    CData/*0:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r;
    CData/*7:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m;
    CData/*0:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_last;
    CData/*7:0*/ __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m;
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __Vtrigprevexpr___TOP__tb_ntt_top__DOT__clk__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP__tb_ntt_top__DOT__rst_n__0;
    CData/*0:0*/ __VactContinue;
    SData/*8:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len;
    SData/*8:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start;
    SData/*8:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j;
    SData/*8:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min;
    SData/*9:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start;
    IData/*23:0*/ tb_ntt_top__DOT__wr_data;
    IData/*23:0*/ tb_ntt_top__DOT__rd_data;
    IData/*31:0*/ tb_ntt_top__DOT__errors;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__tw_data;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_sum;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_diff;
    IData/*31:0*/ __VactIterCount;
    VlUnpacked<IData/*23:0*/, 256> tb_ntt_top__DOT__vin;
    VlUnpacked<IData/*23:0*/, 256> tb_ntt_top__DOT__vexp;
    VlUnpacked<IData/*23:0*/, 256> tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem;
    VlUnpacked<IData/*23:0*/, 127> tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_k;
    VlUnpacked<IData/*23:0*/, 255> tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_d;
    VlDelayScheduler __VdlySched;
    VlTriggerScheduler __VtrigSched_h7aa3ac98__0;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<3> __VactTriggered;
    VlTriggerVec<3> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vtb_ntt_top__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vtb_ntt_top___024root(Vtb_ntt_top__Syms* symsp, const char* v__name);
    ~Vtb_ntt_top___024root();
    VL_UNCOPYABLE(Vtb_ntt_top___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
