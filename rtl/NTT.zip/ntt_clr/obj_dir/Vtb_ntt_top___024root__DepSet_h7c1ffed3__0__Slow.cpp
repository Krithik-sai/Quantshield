// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_ntt_top.h for the primary calling header

#include "Vtb_ntt_top__pch.h"
#include "Vtb_ntt_top___024root.h"

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_static__TOP(Vtb_ntt_top___024root* vlSelf);

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_static(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_static\n"); );
    // Body
    Vtb_ntt_top___024root___eval_static__TOP(vlSelf);
}

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_static__TOP(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_static__TOP\n"); );
    // Body
    vlSelf->tb_ntt_top__DOT__clk = 0U;
    vlSelf->tb_ntt_top__DOT__rst_n = 0U;
    vlSelf->tb_ntt_top__DOT__sel = 0U;
    vlSelf->tb_ntt_top__DOT__start = 0U;
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__wr_addr = 0U;
    vlSelf->tb_ntt_top__DOT__rd_addr = 0U;
    vlSelf->tb_ntt_top__DOT__wr_data = 0U;
    vlSelf->tb_ntt_top__DOT__errors = 0U;
}

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_initial__TOP(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_initial__TOP\n"); );
    // Body
    VL_READMEM_N(true, 24, 127, 0, std::string{"twiddle/kyber_twiddles_hex_correct.mem"}
                 ,  &(vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_k)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 255, 0, std::string{"twiddle/dilithium_twiddles_hex_correct.mem"}
                 ,  &(vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_d)
                 , 0, ~0ULL);
}

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_final(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_final\n"); );
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__stl(Vtb_ntt_top___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vtb_ntt_top___024root___eval_phase__stl(Vtb_ntt_top___024root* vlSelf);

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_settle(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_settle\n"); );
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelf->__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vtb_ntt_top___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("tb/tb_ntt_top.sv", 4, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vtb_ntt_top___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelf->__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__stl(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtb_ntt_top___024root___stl_sequent__TOP__0(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___stl_sequent__TOP__0\n"); );
    // Init
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x = 0;
    VlWide<3>/*95:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu;
    VL_ZERO_W(96, tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu);
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r = 0;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw = 0;
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_2;
    // Body
    if (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min = 1U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0x7fe001U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0x200801cULL;
    } else {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min = 2U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0xd01U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0x13afb7680bULL;
    }
    vlSelf->tb_ntt_top__DOT__rd_data = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem
        [vlSelf->tb_ntt_top__DOT__rd_addr];
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start 
        = (0x3ffU & ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start) 
                     + ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len) 
                        << 1U)));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_last 
        = ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j) 
           == (0x1ffU & (((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start) 
                          + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len)) 
                         - (IData)(1U))));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
        = (0xffffffffffffULL & ((QData)((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r)) 
                                * (QData)((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r))));
    __Vtemp_1[0U] = (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x);
    __Vtemp_1[1U] = (IData)((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
                             >> 0x20U));
    __Vtemp_1[2U] = 0U;
    __Vtemp_2[0U] = (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU);
    __Vtemp_2[1U] = (IData)((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU 
                             >> 0x20U));
    __Vtemp_2[2U] = 0U;
    VL_MUL_W(3, tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu, __Vtemp_1, __Vtemp_2);
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest 
        = (0xffffffffffffULL & (((QData)((IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu[2U])) 
                                 << 0x10U) | ((QData)((IData)(
                                                              tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu[1U])) 
                                              >> 0x10U)));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full 
        = (0xffffffffffffULL & (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
                                - (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest 
                                   * (QData)((IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)))));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
        = (0x1ffffffU & (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t 
        = (0xffffffU & ((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
                         >= tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
                            - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
        = (0x1ffffffU & (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r 
                         + tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_sum 
        = (0xffffffU & ((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
                         >= tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
                            - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw 
        = (0x1ffffffU & (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r 
                         - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_diff 
        = (0xffffffU & ((0x1000000U & tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw 
                            + tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw));
}

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_stl(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vtb_ntt_top___024root___stl_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_triggers__stl(Vtb_ntt_top___024root* vlSelf);

VL_ATTR_COLD bool Vtb_ntt_top___024root___eval_phase__stl(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_phase__stl\n"); );
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vtb_ntt_top___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelf->__VstlTriggered.any();
    if (__VstlExecute) {
        Vtb_ntt_top___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__act(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge tb_ntt_top.clk or negedge tb_ntt_top.rst_n)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(posedge tb_ntt_top.clk)\n");
    }
    if ((4ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__nba(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge tb_ntt_top.clk or negedge tb_ntt_top.rst_n)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(posedge tb_ntt_top.clk)\n");
    }
    if ((4ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 2 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtb_ntt_top___024root___ctor_var_reset(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->tb_ntt_top__DOT__clk = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__rst_n = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__sel = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__start = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__done = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__wr_en = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__wr_addr = VL_RAND_RESET_I(8);
    vlSelf->tb_ntt_top__DOT__rd_addr = VL_RAND_RESET_I(8);
    vlSelf->tb_ntt_top__DOT__wr_data = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__rd_data = VL_RAND_RESET_I(24);
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->tb_ntt_top__DOT__vin[__Vi0] = VL_RAND_RESET_I(24);
    }
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->tb_ntt_top__DOT__vexp[__Vi0] = VL_RAND_RESET_I(24);
    }
    vlSelf->tb_ntt_top__DOT__errors = 0;
    vlSelf->tb_ntt_top__DOT__dut__DOT__tw_data = VL_RAND_RESET_I(24);
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem[__Vi0] = VL_RAND_RESET_I(24);
    }
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = VL_RAND_RESET_I(2);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len = VL_RAND_RESET_I(9);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start = VL_RAND_RESET_I(9);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j = VL_RAND_RESET_I(9);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m = VL_RAND_RESET_I(8);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_sum = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_diff = VL_RAND_RESET_I(24);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min = VL_RAND_RESET_I(9);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_last = VL_RAND_RESET_I(1);
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start = VL_RAND_RESET_I(10);
    for (int __Vi0 = 0; __Vi0 < 127; ++__Vi0) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_k[__Vi0] = VL_RAND_RESET_I(24);
    }
    for (int __Vi0 = 0; __Vi0 < 255; ++__Vi0) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_d[__Vi0] = VL_RAND_RESET_I(24);
    }
    vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m = VL_RAND_RESET_I(8);
    vlSelf->__Vtrigprevexpr___TOP__tb_ntt_top__DOT__clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__tb_ntt_top__DOT__rst_n__0 = VL_RAND_RESET_I(1);
}
