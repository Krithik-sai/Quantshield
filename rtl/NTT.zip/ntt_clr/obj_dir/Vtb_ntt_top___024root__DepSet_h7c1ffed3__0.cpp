// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtb_ntt_top.h for the primary calling header

#include "Vtb_ntt_top__pch.h"
#include "Vtb_ntt_top___024root.h"

VL_ATTR_COLD void Vtb_ntt_top___024root___eval_initial__TOP(Vtb_ntt_top___024root* vlSelf);
VlCoroutine Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__0(Vtb_ntt_top___024root* vlSelf);
VlCoroutine Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__1(Vtb_ntt_top___024root* vlSelf);

void Vtb_ntt_top___024root___eval_initial(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_initial\n"); );
    // Body
    Vtb_ntt_top___024root___eval_initial__TOP(vlSelf);
    Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    vlSelf->__Vtrigprevexpr___TOP__tb_ntt_top__DOT__clk__0 
        = vlSelf->tb_ntt_top__DOT__clk;
    vlSelf->__Vtrigprevexpr___TOP__tb_ntt_top__DOT__rst_n__0 
        = vlSelf->tb_ntt_top__DOT__rst_n;
}

VL_INLINE_OPT VlCoroutine Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__0(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__0\n"); );
    // Init
    IData/*31:0*/ tb_ntt_top__DOT__cycles;
    tb_ntt_top__DOT__cycles = 0;
    CData/*0:0*/ __Vtask_tb_ntt_top__DOT__run__0__s;
    __Vtask_tb_ntt_top__DOT__run__0__s = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__0__tag;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__0__t;
    __Vtask_tb_ntt_top__DOT__run__0__t = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__0__fi;
    std::string __Vtask_tb_ntt_top__DOT__run__0__fe;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__0__e;
    __Vtask_tb_ntt_top__DOT__run__0__e = 0;
    CData/*0:0*/ __Vtask_tb_ntt_top__DOT__run__1__s;
    __Vtask_tb_ntt_top__DOT__run__1__s = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__1__tag;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__1__t;
    __Vtask_tb_ntt_top__DOT__run__1__t = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__1__fi;
    std::string __Vtask_tb_ntt_top__DOT__run__1__fe;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__1__e;
    __Vtask_tb_ntt_top__DOT__run__1__e = 0;
    CData/*0:0*/ __Vtask_tb_ntt_top__DOT__run__2__s;
    __Vtask_tb_ntt_top__DOT__run__2__s = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__2__tag;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__2__t;
    __Vtask_tb_ntt_top__DOT__run__2__t = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i = 0;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i;
    __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i = 0;
    std::string __Vtask_tb_ntt_top__DOT__run__2__fi;
    std::string __Vtask_tb_ntt_top__DOT__run__2__fe;
    IData/*31:0*/ __Vtask_tb_ntt_top__DOT__run__2__e;
    __Vtask_tb_ntt_top__DOT__run__2__e = 0;
    // Body
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    vlSelf->tb_ntt_top__DOT__rst_n = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       42);
    __Vtask_tb_ntt_top__DOT__run__0__t = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__tag = std::string{"kyber"};
    __Vtask_tb_ntt_top__DOT__run__0__s = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    __Vtask_tb_ntt_top__DOT__run__0__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__0__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__0__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__0__t,
                          32,__Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__0__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__0__e);
        }
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__0__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,__Vtask_tb_ntt_top__DOT__run__0__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__0__e);
    __Vtask_tb_ntt_top__DOT__run__1__t = 0U;
    __Vtask_tb_ntt_top__DOT__run__1__tag = std::string{"dil"};
    __Vtask_tb_ntt_top__DOT__run__1__s = 1U;
    __Vtask_tb_ntt_top__DOT__run__1__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__1__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    __Vtask_tb_ntt_top__DOT__run__1__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__1__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__1__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__1__t,
                          32,__Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__1__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__1__e);
        }
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__1__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,__Vtask_tb_ntt_top__DOT__run__1__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__1__e);
    __Vtask_tb_ntt_top__DOT__run__0__t = 1U;
    __Vtask_tb_ntt_top__DOT__run__0__tag = std::string{"kyber"};
    __Vtask_tb_ntt_top__DOT__run__0__s = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    __Vtask_tb_ntt_top__DOT__run__0__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__0__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__0__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__0__t,
                          32,__Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__0__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__0__e);
        }
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__0__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,__Vtask_tb_ntt_top__DOT__run__0__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__0__e);
    __Vtask_tb_ntt_top__DOT__run__1__t = 1U;
    __Vtask_tb_ntt_top__DOT__run__1__tag = std::string{"dil"};
    __Vtask_tb_ntt_top__DOT__run__1__s = 1U;
    __Vtask_tb_ntt_top__DOT__run__1__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__1__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    __Vtask_tb_ntt_top__DOT__run__1__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__1__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__1__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__1__t,
                          32,__Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__1__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__1__e);
        }
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__1__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,__Vtask_tb_ntt_top__DOT__run__1__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__1__e);
    __Vtask_tb_ntt_top__DOT__run__0__t = 2U;
    __Vtask_tb_ntt_top__DOT__run__0__tag = std::string{"kyber"};
    __Vtask_tb_ntt_top__DOT__run__0__s = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__0__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    __Vtask_tb_ntt_top__DOT__run__0__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__0__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__0__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__0__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__0__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__0__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__0__t,
                          32,__Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__0__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__0__e);
        }
        __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__0__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__0__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__0__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__0__t,
                  32,__Vtask_tb_ntt_top__DOT__run__0__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__0__e);
    __Vtask_tb_ntt_top__DOT__run__1__t = 2U;
    __Vtask_tb_ntt_top__DOT__run__1__tag = std::string{"dil"};
    __Vtask_tb_ntt_top__DOT__run__1__s = 1U;
    __Vtask_tb_ntt_top__DOT__run__1__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__1__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    __Vtask_tb_ntt_top__DOT__run__1__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__1__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__1__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__1__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__1__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__1__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__1__t,
                          32,__Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__1__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__1__e);
        }
        __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__1__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__1__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__1__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__1__t,
                  32,__Vtask_tb_ntt_top__DOT__run__1__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__1__e);
    __Vtask_tb_ntt_top__DOT__run__2__t = 0U;
    __Vtask_tb_ntt_top__DOT__run__2__tag = std::string{"kyber"};
    __Vtask_tb_ntt_top__DOT__run__2__s = 0U;
    __Vtask_tb_ntt_top__DOT__run__2__e = 0U;
    __Vtask_tb_ntt_top__DOT__run__2__fi = VL_SFORMATF_NX("vectors/%@_in%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__2__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__2__t) ;
    __Vtask_tb_ntt_top__DOT__run__2__fe = VL_SFORMATF_NX("vectors/%@_exp%0d.hex",
                                                         -1,
                                                         &(__Vtask_tb_ntt_top__DOT__run__2__tag),
                                                         32,
                                                         __Vtask_tb_ntt_top__DOT__run__2__t) ;
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__2__fi)
                 ,  &(vlSelf->tb_ntt_top__DOT__vin)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 24, 256, 0, VL_CVT_PACK_STR_NN(__Vtask_tb_ntt_top__DOT__run__2__fe)
                 ,  &(vlSelf->tb_ntt_top__DOT__vexp)
                 , 0, ~0ULL);
    __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i)) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           22);
        vlSelf->tb_ntt_top__DOT__wr_en = 1U;
        vlSelf->tb_ntt_top__DOT__wr_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i);
        vlSelf->tb_ntt_top__DOT__wr_data = vlSelf->tb_ntt_top__DOT__vin
            [(0xffU & __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i)];
        __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__2__unnamedblk1__DOT__i);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       24);
    vlSelf->tb_ntt_top__DOT__wr_en = 0U;
    vlSelf->tb_ntt_top__DOT__sel = __Vtask_tb_ntt_top__DOT__run__2__s;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       25);
    vlSelf->tb_ntt_top__DOT__start = 1U;
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       26);
    vlSelf->tb_ntt_top__DOT__start = 0U;
    tb_ntt_top__DOT__cycles = 0U;
    while ((1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__done)))) {
        co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                           nullptr, 
                                                           "@(posedge tb_ntt_top.clk)", 
                                                           "tb/tb_ntt_top.sv", 
                                                           27);
        tb_ntt_top__DOT__cycles = ((IData)(1U) + tb_ntt_top__DOT__cycles);
    }
    co_await vlSelf->__VtrigSched_h7aa3ac98__0.trigger(0U, 
                                                       nullptr, 
                                                       "@(posedge tb_ntt_top.clk)", 
                                                       "tb/tb_ntt_top.sv", 
                                                       28);
    __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i = 0U;
    while (VL_GTS_III(32, 0x100U, __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i)) {
        vlSelf->tb_ntt_top__DOT__rd_addr = (0xffU & __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i);
        co_await vlSelf->__VdlySched.delay(0x3e8ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           30);
        if ((vlSelf->tb_ntt_top__DOT__rd_data != vlSelf->tb_ntt_top__DOT__vexp
             [(0xffU & __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i)])) {
            if (VL_UNLIKELY(VL_GTS_III(32, 5U, __Vtask_tb_ntt_top__DOT__run__2__e))) {
                VL_WRITEF("MISMATCH %@ t%0d [%0d]: got %0# exp %0#\n",
                          -1,&(__Vtask_tb_ntt_top__DOT__run__2__tag),
                          32,__Vtask_tb_ntt_top__DOT__run__2__t,
                          32,__Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i,
                          24,vlSelf->tb_ntt_top__DOT__rd_data,
                          24,vlSelf->tb_ntt_top__DOT__vexp
                          [(0xffU & __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i)]);
            }
            __Vtask_tb_ntt_top__DOT__run__2__e = ((IData)(1U) 
                                                  + __Vtask_tb_ntt_top__DOT__run__2__e);
        }
        __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i 
            = ((IData)(1U) + __Vtask_tb_ntt_top__DOT__run__2__unnamedblk2__DOT__i);
    }
    if ((0U == __Vtask_tb_ntt_top__DOT__run__2__e)) {
        VL_WRITEF("%@ test %0d: PASS (%0d cycles)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__2__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__2__t,
                  32,tb_ntt_top__DOT__cycles);
    } else {
        VL_WRITEF("%@ test %0d: FAIL (%0d mismatches)\n",
                  -1,&(__Vtask_tb_ntt_top__DOT__run__2__tag),
                  32,__Vtask_tb_ntt_top__DOT__run__2__t,
                  32,__Vtask_tb_ntt_top__DOT__run__2__e);
    }
    vlSelf->tb_ntt_top__DOT__errors = (vlSelf->tb_ntt_top__DOT__errors 
                                       + __Vtask_tb_ntt_top__DOT__run__2__e);
    if ((0U == vlSelf->tb_ntt_top__DOT__errors)) {
        VL_WRITEF("ALL TESTS PASSED\n");
    } else {
        VL_WRITEF("TESTS FAILED\n");
    }
    VL_FINISH_MT("tb/tb_ntt_top.sv", 46, "");
}

VL_INLINE_OPT VlCoroutine Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__1(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_initial__TOP__Vtiming__1\n"); );
    // Body
    while (1U) {
        co_await vlSelf->__VdlySched.delay(0x1388ULL, 
                                           nullptr, 
                                           "tb/tb_ntt_top.sv", 
                                           6);
        vlSelf->tb_ntt_top__DOT__clk = (1U & (~ (IData)(vlSelf->tb_ntt_top__DOT__clk)));
    }
}

VL_INLINE_OPT void Vtb_ntt_top___024root___act_comb__TOP__0(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___act_comb__TOP__0\n"); );
    // Body
    vlSelf->tb_ntt_top__DOT__rd_data = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem
        [vlSelf->tb_ntt_top__DOT__rd_addr];
}

void Vtb_ntt_top___024root___eval_act(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_act\n"); );
    // Body
    if ((6ULL & vlSelf->__VactTriggered.word(0U))) {
        Vtb_ntt_top___024root___act_comb__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void Vtb_ntt_top___024root___nba_sequent__TOP__0(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___nba_sequent__TOP__0\n"); );
    // Init
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x = 0;
    VlWide<3>/*95:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu;
    VL_ZERO_W(96, tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu);
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest = 0;
    QData/*47:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r = 0;
    IData/*23:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw = 0;
    IData/*24:0*/ tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw;
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw = 0;
    CData/*7:0*/ __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0;
    __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 = 0;
    IData/*23:0*/ __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0;
    __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 = 0;
    CData/*0:0*/ __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0;
    __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 = 0;
    CData/*7:0*/ __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1;
    __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1 = 0;
    IData/*23:0*/ __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1;
    __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1 = 0;
    SData/*8:0*/ __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len;
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len = 0;
    SData/*8:0*/ __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j;
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j = 0;
    CData/*1:0*/ __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state;
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 0;
    CData/*7:0*/ __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2;
    __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 = 0;
    IData/*23:0*/ __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2;
    __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 = 0;
    CData/*0:0*/ __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2;
    __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 = 0;
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_2;
    // Body
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state 
        = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state;
    vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m 
        = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m;
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j 
        = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j;
    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len 
        = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len;
    __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 = 0U;
    __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 = 0U;
    if (vlSelf->tb_ntt_top__DOT__rst_n) {
        vlSelf->tb_ntt_top__DOT__done = 0U;
        if ((2U & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state))) {
            if ((1U & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state))) {
                __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 
                    = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_sum;
                __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 = 1U;
                __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0 
                    = (0xffU & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j));
                __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1 
                    = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_diff;
                __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1 
                    = (0xffU & ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j) 
                                + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len)));
                if (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_last) {
                    vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m 
                        = (0xffU & ((IData)(1U) + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m)));
                    if ((0x100U <= (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start))) {
                        if (((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len) 
                             != (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min))) {
                            __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len 
                                = (0x1ffU & VL_SHIFTR_III(9,9,32, (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len), 1U));
                            vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start = 0U;
                            __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j = 0U;
                            __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 1U;
                        } else {
                            __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 0U;
                            vlSelf->tb_ntt_top__DOT__done = 1U;
                        }
                    } else {
                        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start 
                            = (0x1ffU & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start));
                        __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j 
                            = (0x1ffU & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start));
                        __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 1U;
                    }
                } else {
                    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j 
                        = (0x1ffU & ((IData)(1U) + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j)));
                    __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 2U;
                }
            } else {
                vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r 
                    = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem
                    [(0xffU & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j))];
                vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r 
                    = vlSelf->tb_ntt_top__DOT__dut__DOT__tw_data;
                __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 3U;
                vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r 
                    = vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem
                    [(0xffU & ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j) 
                               + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len)))];
            }
        } else if ((1U & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state))) {
            __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 2U;
        } else {
            if (vlSelf->tb_ntt_top__DOT__wr_en) {
                __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 
                    = vlSelf->tb_ntt_top__DOT__wr_data;
                __Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 = 1U;
                __Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2 
                    = vlSelf->tb_ntt_top__DOT__wr_addr;
            }
            if (vlSelf->tb_ntt_top__DOT__start) {
                __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len = 0x80U;
                __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j = 0U;
                vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m = 0U;
                vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r 
                    = vlSelf->tb_ntt_top__DOT__sel;
                vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start = 0U;
                __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 1U;
            }
        }
    } else {
        __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len = 0x80U;
        __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j = 0U;
        vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m = 0U;
        __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state = 0U;
        vlSelf->tb_ntt_top__DOT__done = 0U;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r = 0U;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start = 0U;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r = 0U;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r = 0U;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r = 0U;
    }
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state 
        = __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__state;
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j 
        = __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j;
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len 
        = __Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len;
    if (__Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem[__Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0] 
            = __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v0;
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem[__Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1] 
            = __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v1;
    }
    if (__Vdlyvset__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem[__Vdlyvdim0__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2] 
            = __Vdlyvval__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__mem__v2;
    }
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__nxt_start 
        = (0x3ffU & ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start) 
                     + ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len) 
                        << 1U)));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_last 
        = ((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__j) 
           == (0x1ffU & (((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__blk_start) 
                          + (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len)) 
                         - (IData)(1U))));
    if (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__sel_r) {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min = 1U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0x7fe001U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0x200801cULL;
    } else {
        vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__len_min = 2U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q = 0xd01U;
        tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU = 0x13afb7680bULL;
    }
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
        = (0xffffffffffffULL & ((QData)((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__z_r)) 
                                * (QData)((IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__b_r))));
    __Vtemp_1[0U] = (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x);
    __Vtemp_1[1U] = (IData)((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
                             >> 0x20U));
    __Vtemp_1[2U] = 0U;
    __Vtemp_2[0U] = (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU);
    __Vtemp_2[1U] = (IData)((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__MU 
                             >> 0x20U));
    __Vtemp_2[2U] = 0U;
    VL_MUL_W(3, tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu, __Vtemp_1, __Vtemp_2);
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest 
        = (0xffffffffffffULL & (((QData)((IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu[2U])) 
                                 << 0x10U) | ((QData)((IData)(
                                                              tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__xmu[1U])) 
                                              >> 0x10U)));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full 
        = (0xffffffffffffULL & (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__x 
                                - (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__qest 
                                   * (QData)((IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)))));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
        = (0x1ffffffU & (IData)(tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r_full));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t 
        = (0xffffffU & ((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
                         >= tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r 
                            - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__r));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
        = (0x1ffffffU & (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r 
                         + tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_sum 
        = (0xffffffU & ((tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
                         >= tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw 
                            - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__s_raw));
    tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw 
        = (0x1ffffffU & (vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__a_r 
                         - tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__t));
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__bf_diff 
        = (0xffffffU & ((0x1000000U & tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw)
                         ? (tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw 
                            + tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__Q)
                         : tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__u_bf__DOT__d_raw));
}

VL_INLINE_OPT void Vtb_ntt_top___024root___nba_sequent__TOP__1(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___nba_sequent__TOP__1\n"); );
    // Body
    vlSelf->tb_ntt_top__DOT__dut__DOT__tw_data = ((IData)(vlSelf->tb_ntt_top__DOT__sel)
                                                   ? 
                                                  ((0xfeU 
                                                    >= (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m))
                                                    ? 
                                                   vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_d
                                                   [vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m]
                                                    : 0U)
                                                   : 
                                                  ((0x7eU 
                                                    >= 
                                                    (0x7fU 
                                                     & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m)))
                                                    ? 
                                                   vlSelf->tb_ntt_top__DOT__dut__DOT__u_rom__DOT__rom_k
                                                   [
                                                   (0x7fU 
                                                    & (IData)(vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m))]
                                                    : 0U));
}

VL_INLINE_OPT void Vtb_ntt_top___024root___nba_sequent__TOP__2(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___nba_sequent__TOP__2\n"); );
    // Body
    vlSelf->tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m 
        = vlSelf->__Vdly__tb_ntt_top__DOT__dut__DOT__u_ctrl__DOT__m;
}

void Vtb_ntt_top___024root___eval_nba(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtb_ntt_top___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtb_ntt_top___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((7ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtb_ntt_top___024root___act_comb__TOP__0(vlSelf);
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtb_ntt_top___024root___nba_sequent__TOP__2(vlSelf);
    }
}

void Vtb_ntt_top___024root___timing_resume(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___timing_resume\n"); );
    // Body
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VtrigSched_h7aa3ac98__0.resume("@(posedge tb_ntt_top.clk)");
    }
    if ((4ULL & vlSelf->__VactTriggered.word(0U))) {
        vlSelf->__VdlySched.resume();
    }
}

void Vtb_ntt_top___024root___timing_commit(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___timing_commit\n"); );
    // Body
    if ((! (2ULL & vlSelf->__VactTriggered.word(0U)))) {
        vlSelf->__VtrigSched_h7aa3ac98__0.commit("@(posedge tb_ntt_top.clk)");
    }
}

void Vtb_ntt_top___024root___eval_triggers__act(Vtb_ntt_top___024root* vlSelf);

bool Vtb_ntt_top___024root___eval_phase__act(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<3> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtb_ntt_top___024root___eval_triggers__act(vlSelf);
    Vtb_ntt_top___024root___timing_commit(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vtb_ntt_top___024root___timing_resume(vlSelf);
        Vtb_ntt_top___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtb_ntt_top___024root___eval_phase__nba(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtb_ntt_top___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__nba(Vtb_ntt_top___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtb_ntt_top___024root___dump_triggers__act(Vtb_ntt_top___024root* vlSelf);
#endif  // VL_DEBUG

void Vtb_ntt_top___024root___eval(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtb_ntt_top___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("tb/tb_ntt_top.sv", 4, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vtb_ntt_top___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("tb/tb_ntt_top.sv", 4, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vtb_ntt_top___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vtb_ntt_top___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtb_ntt_top___024root___eval_debug_assertions(Vtb_ntt_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vtb_ntt_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtb_ntt_top___024root___eval_debug_assertions\n"); );
}
#endif  // VL_DEBUG
