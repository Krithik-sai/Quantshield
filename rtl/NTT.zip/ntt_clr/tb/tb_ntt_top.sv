`timescale 1ns/1ps
// One DUT instance, sel switched at run time: Kyber, Dilithium, Kyber, ...
// Golden vectors come from the user's Python generators (forward_ntt on their schedule).
module tb_ntt_top;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic sel = 0, start = 0, busy, done, wr_en = 0;
  logic [7:0] wr_addr = 0, rd_addr = 0;
  logic [23:0] wr_data = 0, rd_data;

  ntt_top dut (.*);

  logic [23:0] vin [0:255], vexp [0:255];
  int errors = 0, cycles;

  task automatic run(input bit s, input string tag, input int t);
    string fi, fe; int e = 0;
    fi = $sformatf("vectors/%s_in%0d.hex", tag, t);  fe = $sformatf("vectors/%s_exp%0d.hex", tag, t);
    $readmemh(fi, vin); $readmemh(fe, vexp);
    for (int i = 0; i < 256; i++) begin
      @(posedge clk); wr_en <= 1; wr_addr <= i[7:0]; wr_data <= vin[i];
    end
    @(posedge clk); wr_en <= 0; sel <= s;
    @(posedge clk); start <= 1;
    @(posedge clk); start <= 0; cycles = 0;
    while (!done) begin @(posedge clk); cycles++; end
    @(posedge clk);
    for (int i = 0; i < 256; i++) begin
      rd_addr = i[7:0]; #1;
      if (rd_data !== vexp[i]) begin
        if (e < 5) $display("MISMATCH %s t%0d [%0d]: got %0d exp %0d", tag, t, i, rd_data, vexp[i]);
        e++;
      end
    end
    if (e == 0) $display("%s test %0d: PASS (%0d cycles)", tag, t, cycles);
    else        $display("%s test %0d: FAIL (%0d mismatches)", tag, t, e);
    errors += e;
  endtask

  initial begin
    repeat (4) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    for (int t = 0; t < 3; t++) begin run(0, "kyber", t); run(1, "dil", t); end
    run(0, "kyber", 0);   // switch back after Dilithium
    if (errors == 0) $display("ALL TESTS PASSED"); else $display("TESTS FAILED");
    $finish;
  end
endmodule
