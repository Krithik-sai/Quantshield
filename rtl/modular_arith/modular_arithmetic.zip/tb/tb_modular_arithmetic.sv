`timescale 1ns/1ps

module tb_modular_arithmetic;

    // ------------------------------------------------------------
    // DUT inputs
    // ------------------------------------------------------------

    logic [23:0] a;
    logic [23:0] b;
    logic        sel;

    // ------------------------------------------------------------
    // DUT outputs
    // ------------------------------------------------------------

    logic [23:0] add_result;
    logic [23:0] sub_result;

    // ------------------------------------------------------------
    // Testbench variables
    // ------------------------------------------------------------

    logic [24:0] q;
    logic [24:0] expected_add;
    logic [24:0] expected_sub;

    integer test_count;
    integer fail_count;
    integer i;

    // ------------------------------------------------------------
    // Instantiate Modular Adder
    // ------------------------------------------------------------

    modular_adder u_adder (
        .a      (a),
        .b      (b),
        .sel    (sel),
        .result (add_result)
    );

    // ------------------------------------------------------------
    // Instantiate Modular Subtractor
    // ------------------------------------------------------------

    modular_subtractor u_subtractor (
        .a      (a),
        .b      (b),
        .sel    (sel),
        .result (sub_result)
    );

    // ------------------------------------------------------------
    // Function to select modulus
    // ------------------------------------------------------------

    function automatic [24:0] get_modulus(input logic sel);

        begin
            if (sel == 1'b0)
                get_modulus = 25'd3329;
            else
                get_modulus = 25'd8380417;
        end

    endfunction

    // ------------------------------------------------------------
    // Test task
    // ------------------------------------------------------------

    task automatic check_result(
        input logic [23:0] test_a,
        input logic [23:0] test_b,
        input logic        test_sel
    );

        begin

            // Apply inputs
            a   = test_a;
            b   = test_b;
            sel = test_sel;

            // Allow combinational logic to settle
            #1;

            // Select modulus
            q = get_modulus(test_sel);

            // ====================================================
            // Expected ADD result
            // ====================================================

            expected_add = {1'b0, test_a} + {1'b0, test_b};

            if (expected_add >= q)
                expected_add = expected_add - q;

            // ====================================================
            // Expected SUB result
            // ====================================================

            if (test_a >= test_b)
                expected_sub =
                    {1'b0, test_a} -
                    {1'b0, test_b};
            else
                expected_sub =
                    {1'b0, test_a} -
                    {1'b0, test_b} +
                    q;

            // ====================================================
            // Check ADD
            // ====================================================

            test_count = test_count + 1;

            if (add_result !== expected_add[23:0]) begin

                fail_count = fail_count + 1;

                $display(
                    "ADD FAIL | sel=%0d q=%0d A=%0d B=%0d | DUT=%0d EXPECTED=%0d",
                    test_sel,
                    q,
                    test_a,
                    test_b,
                    add_result,
                    expected_add[23:0]
                );

            end

            // ====================================================
            // Check SUB
            // ====================================================

            test_count = test_count + 1;

            if (sub_result !== expected_sub[23:0]) begin

                fail_count = fail_count + 1;

                $display(
                    "SUB FAIL | sel=%0d q=%0d A=%0d B=%0d | DUT=%0d EXPECTED=%0d",
                    test_sel,
                    q,
                    test_a,
                    test_b,
                    sub_result,
                    expected_sub[23:0]
                );

            end

        end

    endtask

    // ------------------------------------------------------------
    // Main test sequence
    // ------------------------------------------------------------

    initial begin

        test_count = 0;
        fail_count = 0;

        a   = 24'd0;
        b   = 24'd0;
        sel = 1'b0;

        $display("");
        $display("==============================================");
        $display(" MODULAR ADD/SUB SELF-CHECKING TESTBENCH");
        $display("==============================================");

        // ========================================================
        // TESTING q = 3329
        // sel = 0
        // ========================================================

        $display("");
        $display("----------------------------------------------");
        $display("Testing q = 3329 (sel = 0)");
        $display("----------------------------------------------");

        // Basic cases
        check_result(24'd0,    24'd0,    1'b0);
        check_result(24'd100,  24'd200,  1'b0);
        check_result(24'd1000, 24'd2000, 1'b0);

        // Addition requiring modular reduction
        check_result(24'd3000, 24'd1000, 1'b0);

        // Maximum valid coefficient
        check_result(24'd3328, 24'd3328, 1'b0);

        // Boundary cases
        check_result(24'd3328, 24'd0,    1'b0);
        check_result(24'd0,    24'd3328, 1'b0);

        // Subtraction without correction
        check_result(24'd3000, 24'd1000, 1'b0);

        // Subtraction requiring correction
        check_result(24'd1000, 24'd3000, 1'b0);

        // Zero - maximum
        check_result(24'd0, 24'd3328, 1'b0);

        // Same values
        check_result(24'd3328, 24'd3328, 1'b0);

        // ========================================================
        // TESTING q = 8380417
        // sel = 1
        // ========================================================

        $display("");
        $display("----------------------------------------------");
        $display("Testing q = 8380417 (sel = 1)");
        $display("----------------------------------------------");

        // Basic cases
        check_result(24'd0,       24'd0,       1'b1);
        check_result(24'd100,     24'd200,     1'b1);
        check_result(24'd1000000, 24'd2000000, 1'b1);

        // Addition requiring modular reduction
        check_result(24'd5000000, 24'd4000000, 1'b1);

        // Maximum valid coefficient
        check_result(24'd8380416, 24'd8380416, 1'b1);

        // Boundary cases
        check_result(24'd8380416, 24'd0,       1'b1);
        check_result(24'd0,        24'd8380416, 1'b1);

        // Subtraction without correction
        check_result(24'd7000000, 24'd3000000, 1'b1);

        // Subtraction requiring correction
        check_result(24'd3000000, 24'd7000000, 1'b1);

        // Zero - maximum
        check_result(24'd0, 24'd8380416, 1'b1);

        // Same values
        check_result(24'd8380416, 24'd8380416, 1'b1);

        // ========================================================
        // RANDOM TESTING
        // ========================================================

        $display("");
        $display("----------------------------------------------");
        $display("Running random tests...");
        $display("----------------------------------------------");

        // Random tests for q = 3329
        for (i = 0; i < 1000; i = i + 1) begin

            check_result(
                $urandom_range(0, 3328),
                $urandom_range(0, 3328),
                1'b0
            );

        end

        // Random tests for q = 8380417
        for (i = 0; i < 1000; i = i + 1) begin

            check_result(
                $urandom_range(0, 8380416),
                $urandom_range(0, 8380416),
                1'b1
            );

        end

        // ========================================================
        // FINAL SUMMARY
        // ========================================================

        $display("");
        $display("==============================================");
        $display(" TEST SUMMARY");
        $display("==============================================");

        $display("Total checks : %0d", test_count);
        $display("Failures     : %0d", fail_count);

        if (fail_count == 0) begin

            $display("");
            $display("*** ALL TESTS PASSED ***");
            $display("");

        end
        else begin

            $display("");
            $display("*** TESTS FAILED ***");
            $display("");

        end

        $display("==============================================");

        $finish;

    end

endmodule
