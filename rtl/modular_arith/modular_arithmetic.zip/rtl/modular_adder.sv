import Butterfly::*;

module modular_adder (
    input  logic [23:0] a,
    input  logic [23:0] b,
    input  logic        sel,
    output logic [23:0] result
);

    logic [24:0] sum;
    logic [24:0] q;

    always @(*) begin

        // Runtime modulus selection
        if (sel == 1'b0)
            q = {1'b0, Q_KYBER};
        else
            q = {1'b0, Q_DILITHIUM};

        // 25-bit intermediate addition
        sum = {1'b0, a} + {1'b0, b};

        // Modular reduction
        if (sum >= q)
            result = sum - q;
        else
            result = sum[23:0];

    end

endmodule
