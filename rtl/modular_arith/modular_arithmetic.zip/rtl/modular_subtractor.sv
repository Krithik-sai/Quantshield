import Butterfly::*;

module modular_subtractor (
    input  logic [23:0] a,
    input  logic [23:0] b,
    input  logic        sel,
    output logic [23:0] result
);

    logic [24:0] q;

    always @(*) begin

        // Runtime modulus selection
        if (sel == 1'b0)
            q = {1'b0, Q_KYBER};
        else
            q = {1'b0, Q_DILITHIUM};

        // Subtract-and-correct
        if (a >= b)
            result = a - b;
        else
            result = a - b + q;

    end

endmodule
