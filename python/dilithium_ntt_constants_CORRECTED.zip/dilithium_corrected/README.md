# Dilithium NTT Constants -- CORRECTED

Parameters:
- q = 8380417
- N = 256
- root = 1753 (this value is correct and matches the real ML-DSA spec)
- radix = 2, architecture = iterative in-place radix-2 DIT

## What was wrong with the originally uploaded package

1. **Mislabeled root order.** The original README called 1753 a
   "primitive 256th root of unity." It isn't -- its multiplicative
   order mod q is **512**, verified directly: `1753^256 mod q == -1`
   and `1753^512 mod q == 1`. 1753 is the right constant, described
   wrong.

2. **Wrong twiddle formula for that root.** The original generator used
   the generic cyclic-NTT formula `pow(ROOT, j*(N/m), Q)`, which only
   makes sense if `ROOT^N == 1`. Here `ROOT^256 == -1`, so that
   assumption fails. I tested the resulting schedule directly against
   both cyclic (mod X^256-1) and negacyclic (mod X^256+1) convolution --
   it matched **neither**.

3. **Misleading "reference" file.** `dilithium_reference_zetas_*.mem` in
   the original zip is not sourced from the official reference
   implementation. It's just the flawed twiddle table re-ordered by a
   7-bit bit-reversal permutation (`ref[k] == twiddle[bitrev7(k)]`) --
   i.e. it's the same bug, relabeled in a way that looks authoritative.

## Why 8 full stages actually is correct here (unlike Kyber)

Because 1753 has order 512 = 2N, it's a genuine **2N-th root of unity**,
which is exactly what's needed for X^256+1 to split all the way down
into **256 linear factors**. (Contrast with Kyber, q=3329, which only
has a 256th root available -- so Kyber's ring stops at 128 irreducible
quadratics after 7 stages; see the corrected Kyber package.) So for
Dilithium, a full 8-stage decomposition is the right structure -- the
original package's stage *count* wasn't the problem, only the twiddle
*values* were.

Because the split goes all the way to single coefficients, multiplying
two polynomials in the NTT domain is a plain element-wise multiply --
no base-multiplication step needed (unlike Kyber).

## Verification performed

1. Round-trip test: forward NTT then inverse NTT recovers the original
   random input exactly.
2. Full multiplication test: forward NTT -> pointwise multiply -> inverse
   NTT was compared against a direct O(N^2) negacyclic convolution of
   two random polynomials mod (X^256+1). They match exactly.

## Files
- `dilithium_ntt_constants_correct.py`       Source-of-truth generator (run it directly)
- `dilithium_twiddles_decimal_correct.mem`   255 twiddle values, decimal, first-use order
- `dilithium_twiddles_hex_correct.mem`       255 twiddle values, 6-digit hex
- `dilithium_ntt_schedule_correct.csv`       1024 butterfly operations (8 stages)
- `dilithium_leaf_evaluation_points.csv`     the 256 fully-resolved evaluation points
                                              (zeta powers), one per final coefficient
