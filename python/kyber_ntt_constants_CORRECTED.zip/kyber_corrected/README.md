# Kyber NTT Constants -- CORRECTED

Parameters (unchanged from the request):
- q = 3329
- N = 256
- primitive 256th root of unity = 17
- radix = 2, architecture = iterative in-place radix-2 DIT

## What's different from a generic 8-stage NTT

Kyber's ring is Z_q[X]/(X^256 + 1) -- **negacyclic**, not the cyclic ring
Z_q[X]/(X^256 - 1) that a plain textbook Cooley-Tukey NTT assumes.

q = 3329 has a primitive **256th** root of unity (zeta = 17), but no
primitive 512th root. That means X^256 + 1 can only be split into **128
irreducible quadratic factors** -- it cannot be fully decomposed down to
256 scalar (linear) factors. Concretely: zeta's multiplicative order is
256 = 2^8, while (q-1)/2 = 1664 = 2^7 x 13. Since 2^8 does not divide
1664, zeta -- and every odd power of it -- is a quadratic non-residue
mod q, so X^2 - zeta^(odd exponent) never factors further.

Consequence:
- **7 layers**, not 8: 256 -> 128 -> 64 -> 32 -> 16 -> 8 -> 4 -> 2.
- **896 butterfly operations** (7 x 128), not 1024.
- **127 unique twiddle values**, not 128.
- The transform stops at 128 unresolved size-2 blocks (pairs of
  coefficients). Multiplying two polynomials in the NTT domain needs a
  **base multiplication** step per pair -- `(f0+f1*X)*(g0+g1*X) mod
  (X^2 - zeta^e)` -- not a plain element-wise multiply.

## Verification performed

This package was built and checked with actual code, not derived by
hand:
1. Round-trip test: forward NTT followed by inverse NTT recovers the
   original random input exactly.
2. Full multiplication test: forward NTT -> base multiplication at each
   of the 128 leaves -> inverse NTT was compared against a direct O(N^2)
   negacyclic convolution of two random polynomials mod (X^256+1). They
   match exactly.

## Files
- `kyber_ntt_constants_correct.py`   Source-of-truth generator (run it directly)
- `kyber_twiddles_decimal_correct.mem`   127 twiddle values, decimal, first-use order
- `kyber_twiddles_hex_correct.mem`       127 twiddle values, 4-digit hex
- `kyber_ntt_schedule_correct.csv`       896 butterfly operations (7 stages)
- `kyber_leaf_blocks.csv`                the 128 terminal quadratic-factor blocks
                                          needed for the base-multiplication step

## Note on the originally uploaded `kyber_ntt_constants.zip`

That package's generator used a generic 8-stage full-decomposition
schedule (`exponent = j * (N/m)`, stages 1..8 down to m=2, half=1). It is
internally self-consistent (its own .py, .csv and .mem files all agree
with each other) and, if you feed it into a correctness test, it turns
out to correctly implement a **cyclic** NTT (mod X^256 - 1) -- just not
the negacyclic one Kyber actually needs. Verified by direct convolution
comparison: it reproduces cyclic convolution exactly, and does not
reproduce negacyclic convolution at all.
